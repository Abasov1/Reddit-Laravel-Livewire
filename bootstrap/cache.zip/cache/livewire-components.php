<?php return array (
  'auth-live' => 'App\\Http\\Livewire\\AuthLive',
  'chat-live' => 'App\\Http\\Livewire\\ChatLive',
  'comment-live' => 'App\\Http\\Livewire\\CommentLive',
  'filter-subreddit' => 'App\\Http\\Livewire\\FilterSubreddit',
  'friend-request' => 'App\\Http\\Livewire\\FriendRequest',
  'live-subsettings' => 'App\\Http\\Livewire\\LiveSubsettings',
  'live-user-settings' => 'App\\Http\\Livewire\\LiveUserSettings',
  'other-notifications' => 'App\\Http\\Livewire\\OtherNotifications',
  'search-live' => 'App\\Http\\Livewire\\SearchLive',
  'subcommentus' => 'App\\Http\\Livewire\\Subcommentus',
  'test' => 'App\\Http\\Livewire\\Test',
);